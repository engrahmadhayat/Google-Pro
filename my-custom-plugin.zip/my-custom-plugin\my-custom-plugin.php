<?php
/**
 * Plugin Name: My Custom Plugin
 * Plugin URI: http://yourwebsite.com/
 * Description: This is my very first custom WordPress plugin.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: http://yourwebsite.com/
 * License: GPL2
 */

// Security check: Prevent direct access to the file
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function my_custom_admin_notice() {
    echo '<div class="notice notice-success is-dismissible">
             <p>🎉 Congratulations! Your first custom plugin is active and working beautifully!</p>
          </div>';
}
// This hook tells WordPress to run our function when showing admin notices
add_action('admin_notices', 'my_custom_admin_notice');

// Ek simple shortcode banate hain
function my_custom_shortcode_function() {
    return "<div style='background-color: #f1f1f1; padding: 20px; border-left: 5px solid #0073aa;'>
                <h3>Hello Sir! 👋</h3>
                <p>Ye mera custom plugin hai aur ye text shortcode ke zariye show ho raha hai.</p>
            </div>";
}
// WordPress ko batayen ke jab bhi [demo_shortcode] likha jaye, toh upper wala function chalaye
add_shortcode('demo_shortcode', 'my_custom_shortcode_function');
